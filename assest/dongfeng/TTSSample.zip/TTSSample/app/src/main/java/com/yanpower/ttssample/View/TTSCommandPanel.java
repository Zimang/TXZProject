package com.yanpower.ttssample.View;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yanpower.tteservice.TTSCommand;
import com.yanpower.ttssample.R;

public class TTSCommandPanel extends LinearLayout implements View.OnClickListener {
    private TextView title;
    private TTSCommandSpinner ttsCommandSpinner;
    private EditText params;
    private Button send;
    public TTSCommandPanel(Context context) {
        this(context, null);
    }
    public TTSCommandPanel(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }
    public TTSCommandPanel(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setupTTSCommandPanelUI(context, attrs);
        loadAttributeSet(context, attrs);
    }
    private void setupTTSCommandPanelUI(Context context, AttributeSet attrs){
        View.inflate(context, R.layout.layout_ttscommand_panel, this);
        title = findViewById(R.id.title);
        ttsCommandSpinner = findViewById(R.id.ttsCommandSpinner);
        params = findViewById(R.id.params);
        send = findViewById(R.id.send);
    }
    private void loadAttributeSet(Context context, AttributeSet attrs){
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.TTSCommandPanel);
        String title = ta.getString(R.styleable.TTSCommandPanel_title);
        int ttstype = ta.getInt(R.styleable.TTSCommandPanel_ttstype, TTSCommandSpinner.TYPE_UNKNOW);
        this.title.setText(title);
        this.ttsCommandSpinner.buildTTSCommand(ttstype);
        ta.recycle();
    }
    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        send.setOnClickListener(this);
    }
    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        send.setOnClickListener(null);
    }
    @Override
    public void onClick(View view) {
        notifySend();
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private TTSCommandListener ttsCommandListener;
    public void setTtsCommandListener(TTSCommandListener ttsCommandListener) {
        this.ttsCommandListener = ttsCommandListener;
    }
    private void notifySend(){
        if(ttsCommandListener!=null) {
            TTSCommand ttsCommand = ttsCommandSpinner.getSelectedTTSCommand();
            float input = 0.f;
            try {
                String inputString = params.getText().toString();
                input = Float.parseFloat(inputString);
            } catch (Throwable e) {
                //e.printStackTrace();
            }
            ttsCommandListener.onTTSCommandSend(ttsCommand, input);
        }
    }
}
