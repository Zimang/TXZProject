package com.yanpower.ttssample.View;

import com.yanpower.tteservice.TTSCommand;

public interface TTSCommandListener {
    public void onTTSCommandSend(TTSCommand ttsCommand, float input);
}
