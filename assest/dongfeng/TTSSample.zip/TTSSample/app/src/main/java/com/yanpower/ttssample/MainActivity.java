package com.yanpower.ttssample;

import android.app.Activity;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.yanpower.tteservice.TTSCommand;
import com.yanpower.ttssample.View.TTSCommandListener;
import com.yanpower.ttssample.View.TTSCommandPanel;
import com.yanpower.ttssdk.Modules.Sdk.SimpleSDKProxy;
import com.yanpower.ttsservice.TTSRequest;
import com.yanpower.ttsservice.TTSResponse;

public class MainActivity extends Activity implements TTSCommandListener {
    private String TAG = "MainActivity";
    private TestSDK testSDK;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        controlPanel = findViewById(R.id.controlPanel);
        sdk = findViewById(R.id.sdk);
        requestTextView = findViewById(R.id.request);
        callback = findViewById(R.id.callback);
        music = findViewById(R.id.music);
        fm = findViewById(R.id.fm);
        volume = findViewById(R.id.volume);
        ac = findViewById(R.id.ac);
        assistTouch = findViewById(R.id.assistTouch);
        initTTSCommandPanel();
        testSDK = new TestSDK();
        updateSDK();
    }
    ///////////////////////////////////////////////////////////////////////////////
    private TTSCommandPanel music;
    private TTSCommandPanel fm;
    private TTSCommandPanel volume;
    private TTSCommandPanel ac;
    private TTSCommandPanel assistTouch;
    private void initTTSCommandPanel(){
        music.setTtsCommandListener(this);
        fm.setTtsCommandListener(this);
        volume.setTtsCommandListener(this);
        ac.setTtsCommandListener(this);
        assistTouch.setTtsCommandListener(this);
    }
    @Override
    public void onTTSCommandSend(TTSCommand ttsCommand, float input) {
        Log.e(TAG, "onTTSCommandSend ttsCommand:" + ttsCommand + ", input:" + input);
        if(testSDK!=null&&ttsCommand!=null){
            if(ttsCommand == TTSCommand.RADIO_AM
                || ttsCommand == TTSCommand.RADIO_FM
                || ttsCommand == TTSCommand.AC_TEMP_SET){
                testSDK.dispatchTTSRequest(ttsCommand, input);
            } else if(ttsCommand == TTSCommand.AC_FEN_SET){
                testSDK.dispatchTTSRequest(ttsCommand, (int)input);
            }else {
                testSDK.dispatchTTSRequest(ttsCommand);
            }
        }
    }
    ///////////////////////////////////////////////////////////////////////////////
    private View controlPanel;
    private TextView sdk;
    private TextView callback;
    private TextView requestTextView;
    private void updateSDK(){
        updateTextView(sdk, testSDK.getSDKInfo());
        controlPanel.setEnabled(testSDK.isSDKReady());
    }
    private void updateTextView(TextView textView, String info){
        textView.setText(Html.fromHtml(info));
    }

    ///////////////////////////////////////////////////////////////////////////////
    private class TestSDK extends SimpleSDKProxy{
        @Override
        public void onSDKRequestShowOrHideTTS(boolean show)  {
            Log.e(TAG, "onSDKRequestShowOrHideTTS show:" + show );
            updateTextView(callback, getHtmlString("收到SDK请求交互", "" + show));
        }
        @Override
        public void onSDKTTSEnableChange(boolean enable){
            Log.e(TAG, "onSDKTTSEnableChange enable:" + enable );
            updateTextView(callback, getHtmlString("收到TTS使能状态变化", "" + enable));
            updateSDK();
        }
        @Override
        public void onSDKReadyChange(boolean ready){
            Log.e(TAG, "onSDKReadyChange ready:" + ready );
            updateTextView(callback, getHtmlString("收到SDK准备状态变化", "" + ready));
            updateSDK();
        }
        //////////////////////////////////////////////////////////////////////////////////////
        @Override
        public TTSResponse dispatchTTSRequest(TTSRequest request) {
            TTSResponse response = super.dispatchTTSRequest(request);
            updateTTSCommandInfo(request, response);
            return response;
        }
        public String getSDKInfo(){
            StringBuffer sb = new StringBuffer();
            sb.append(getHtmlString("isSDKReady:", "" + isSDKReady()));
            sb.append(getHtmlString("isEnableTTS:", "" + isEnableTTS()));
            return sb.toString();
        }
        private void updateTTSCommandInfo(TTSRequest request, TTSResponse response){
            StringBuffer sb = new StringBuffer();
            String requestInfo = "";
            if(request!=null){
                TTSCommand command = TTSCommand.getTTSCommand(request.getCommand());
                requestInfo += (command.toString() + "<br/>");
            }
            sb.append(getHtmlString("客户端下发命令：", requestInfo));
            String responseInfo = "";
            if(response!=null){
                responseInfo += ("命令解析：" + response.getCommand() + "<br/>");
                responseInfo += ("处理成功：" +  response.isSuccess() + "<br/>");
                responseInfo += ("已经分发：" +  response.isDispatched() + "<br/>");
                responseInfo += ("应答信息：" + response.getResponseMsg() + "<br/>");
                responseInfo += ("成功信息：" + response.getSuccessMsg() + "<br/>");
                responseInfo += ("需要TTS语音应答：" + response.isNeedTTS() + "<br/>");
            }
            sb.append(getHtmlString("服务端命令应答：", responseInfo));
            //需要客户端自行播放语音应答，这里只做解析
            sb.append(getHtmlString("客户端需要播放的语音应答：", parserTTSFromTTSResponse(response)));
            updateTextView(requestTextView, sb.toString());
        }
    }
    private String getHtmlString(String key, String value){
        return "<br/><font color='green' size='20'>" + key
                + "</font>:<br/><font color='red' size='20'>" + value + "</font>";
    }
}
