package com.yanpower.ttssample;

import android.app.Application;
import com.yanpower.ttssdk.TTSSDK;

public class TTSSampleApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        //必须初始化SDK， 才能使用SDK的能力
        TTSSDK.initTTSSDK(this);
    }
}
