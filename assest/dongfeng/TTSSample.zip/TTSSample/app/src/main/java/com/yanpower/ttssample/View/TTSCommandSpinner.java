package com.yanpower.ttssample.View;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.yanpower.tteservice.TTSCommand;
import static com.yanpower.tteservice.TTSCommand.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TTSCommandSpinner extends Spinner implements AdapterView.OnItemSelectedListener {
    public final static String TAG = "TTSCommandSpinner";
    public final static int TYPE_UNKNOW = 0;
    public final static int TYPE_MUSIC = 1;
    public final static int TYPE_RADIO = 2;
    public final static int TYPE_VOLUME = 3;

    public final static int TYPE_AC = 4;
    public final static int TYPE_ASSISTOUCH = 5;
    public TTSCommandSpinner(Context context) {
        super(context);
    }

    public TTSCommandSpinner(Context context, int mode) {
        super(context, mode);
    }

    public TTSCommandSpinner(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public TTSCommandSpinner(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public TTSCommandSpinner(Context context, AttributeSet attrs, int defStyleAttr, int mode) {
        super(context, attrs, defStyleAttr, mode);
    }

    public TTSCommandSpinner(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes, int mode) {
        super(context, attrs, defStyleAttr, defStyleRes, mode);
    }

    public TTSCommandSpinner(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes, int mode, Resources.Theme popupTheme) {
        super(context, attrs, defStyleAttr, defStyleRes, mode, popupTheme);
    }
    public void buildTTSCommand(int type){
        if(commandType!=type) {
            commandType = type;
            switch (commandType) {
                case TYPE_MUSIC: {
                    bindTTSCommand(Arrays.asList(MUSIC_PAUSE, MUSIC_PLAY,
                            MUSIC_NEXT, MUSIC_PRE, MUSIC_OPEN,
                            MUSIC_CLOSE));
                }break;
                case TYPE_RADIO:{
                    bindTTSCommand(Arrays.asList(RADIO_OPEN, RADIO_PAUSE_RADIO,
                            RADIO_PAUSE_STATION, RADIO_CLOSE, RADIO_NEXT,
                            RADIO_PRE, RADIO_FM, RADIO_AM));
                }break;
                case TYPE_VOLUME:{
                    bindTTSCommand(Arrays.asList(VOLUME_MUTE, VOLUME_UNMUTE,
                            VOLUME_UP, VOLUME_UP_LITTLE, VOLUME_DOWN,
                            VOLUME_DOWN_LITTLE));
                }break;
                case TYPE_AC:{
                    bindTTSCommand(Arrays.asList(AC_OPEN, AC_CLOSE,
                            AC_OPEN_AC, AC_CLOSE_AC, AC_TEMP_ADD,
                            AC_TEMP_DESC, AC_TEMP_ADD2, AC_TEMP_DESC2,
                            AC_TEMP_SET, AC_TEMP_MAX, AC_TEMP_MIN,
                            AC_FEN_MAX, AC_FEN_MIN, AC_FEN_SET,
                            AC_FEN_ADD, AC_FEN_DESC, AC_MODE_CMD_BLOWFACE,
                            AC_MODE_CMD_BLOWFOOT, AC_MODE_CMD_BLOWFACE_AND_BLOWFOOT,
                            AC_MODE_CMD_BLOWFOOT_AND_CLEANFROST));
                }break;
                case TYPE_ASSISTOUCH:{
                    bindTTSCommand(Arrays.asList(ASSISTOUCH_OPEN_DOORWIN, ASSISTOUCH_CLOSE_DOORWIN,
                            ASSISTOUCH_OPEN_TIANCHUAN, ASSISTOUCH_CLOSE_TIANCHUAN));
                }break;
            }
        }
    }
    private void bindTTSCommand(List<TTSCommand> commandList){
        if(commandList!=null&&commandList.size()>0){
            ttsCommands = commandList;
        } else {
            ttsCommands = new ArrayList<>();
        }
        String[] titles = new String[ttsCommands.size()];
        for(int index=0;index<titles.length;index++){
            titles[index] = ttsCommands.get(index).toString();
        }
        ArrayAdapter adapter = new ArrayAdapter(getContext(), android.R.layout.simple_spinner_item, titles);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        setAdapter(adapter);
        setOnItemSelectedListener(this);
    }
    private int commandType = TYPE_UNKNOW;
    private List<TTSCommand> ttsCommands = new ArrayList<>();

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        Log.d(TAG,"onItemSelected index:" + i + ", " + ttsCommands.get(i)
                + ", " + getSelectedTTSCommand());
    }
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        Log.d(TAG, "onNothingSelected");
    }
    public TTSCommand getSelectedTTSCommand(){
        int index = getSelectedItemPosition();
        Log.d(TAG, "index=" + index + ", size=" + ttsCommands.size());
        if(index>=0){
            return ttsCommands.get(index);
        }
        return null;
    }
}

